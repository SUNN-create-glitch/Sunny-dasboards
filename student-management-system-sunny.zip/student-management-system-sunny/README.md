# Student Management System

A simple **Student Management System** developed as a college project using Python.

## Author

**Sunny Kumar Chaudhary**

**Course:** B.Tech, 2nd Year  
**College:** Government Engineering College Kishanganj

## Features

- Add student records
- View all student records
- Search students by roll number
- Update student information
- Delete student records
- Automatically save records in a JSON file

## Technologies Used

- Python 3
- JSON for local data storage

## How to Run

1. Install Python 3.
2. Clone or download this repository.
3. Open the project folder in Terminal/Command Prompt.
4. Run:

```bash
python student_management.py
```

## Project Structure

```text
student-management-system-sunny/
├── student_management.py
├── README.md
├── requirements.txt
├── .gitignore
└── students.json
```

## Author

Sunny Kumar Chaudhary
